## ***************************************************************************
## ************* run a couple simulations ***************
## ***************************************************
setwd('~/Desktop/pred-prey')
rm(list=ls())
source('src/misc.R')
source('src/meta-functions.R')
source('src/prms.R')
source('src/population.R')
source('src/plotting.R')

set.seed(1)

## ***************************************************************************
## ***************************************************************************

## create parameter list for 1 patch run
prms.1 <- base.prms(

  init.traits=list(C=c(0.05,1,1),
                   R=c(1,1,1)),
  mut.weights=list(C=c(1,0,0),
                   R=c(0,0,0)),

  ## 1 patch scenario
  P=1,
  K=1e5/1,
  a.0=0.0005*1,
  
  n.saves=1e4,
  n.gens=1e4,
  burnin=1e3,
  max.burnin.tries=10,
  print.every=1e3
)

## create parameter list for 200 patch run
prms.200 <- base.prms(

  init.traits=list(C=c(0.05,1,1),
                   R=c(1,1,1)),
  mut.weights=list(C=c(1,0,0),
                   R=c(0,0,0)),

  ## 200 patch scenario
  P=200,
  K=1e5/200,
  a.0=0.0005*200,
  
  n.saves=1e4,
  n.gens=1e4,
  burnin=1e3,
  max.burnin.tries=10,
  print.every=1e3
)

## run model (1 patch)
out.1   <- run.sim(prms=prms.1,   print=T, plot=F)
## run model (200 patch)
out.200 <- run.sim(prms=prms.200, print=T, plot=F)

## ------------------------------------------------------------
## plot output

cols <- c(x='black',
          C='orange',
          R='green4')
## cols <- rep('white', 3)

make.fig <- function(file.name) {

  g <- function() {

    layout(matrix(c(3,3,0,4,4,
                    0,1,1,1,0,
                    0,0,0,0,7,
                    5,5,0,6,6,
                    0,2,2,2,0),
                  5, 5, byrow=TRUE),
           heights=c(1.25,2.75,0.1,1.25,2.75),
           widths=c(0.1,0.2,0.3,0.2,0.1)
           )
    ## layout(matrix(c(3,3,0,4,4,0,5,5,0,6,6,
    ##                 0,1,1,1,0,7,0,2,2,2,0),
    ##               2, 11, byrow=TRUE),
    ##        heights=c(1,2.5),
    ##        widths=c(0.1,0.2,0.3,0.2,0.1,0.2,0.1,0.2,0.3,0.2,0.1)
    ##        )
    ## 
    par(oma=c(1.5,1.8,0.5,1.4), mar=c(1.5,0.5,0.3,0.1),
        mgp=c(1,0.2,0), tcl=0.1, cex.axis=0.7, cex.main=0.7)
    
    add.panel <- function(prms, out, size, lab) {

      ## make an empty plot
      out <- out[!sapply(out, is.null)]
      max.num <- max(sapply(out, function(x)
        max(c(x[['C']]$counts, x[['R']]$counts))))
      x.vals <- as.numeric(names(out))

      if(size =='LITTLE'){
        plot(NA,
             xlim=range(x.vals),
             ylim=c(0,prms$K),
             xlab='',
             ylab='',
             xaxt='n',
             yaxt='n',
             las=1)
        ## y-axis
        axis(2, las=1, at=c(0,prms$K), labels=c(0,prms$K))
      } else {
        plot(NA,
             xlim=range(x.vals),
             ylim=c(0,prms$K),
             xlab='',
             ylab='',
             xaxt ='n',
             las=1)
        ## x axis
        axis(1,
             at=seq.int(from=0,to=prms$n.gens,length=10),
             labels=c(1:10))
      }

      options(scipen=1e5)
      add.lines <- function(case){
        cc <- ifelse(case=='C', cols['C'], cols['R'])
        lwd <- ifelse(size=='LITTLE', 1, 0.25)
        ## extract counts
        num <- lapply(out, function(x) x[[case]]$counts)
        ## sum totals across types within patches
        num.by.patch <- matrix(sapply(num, colSums),
                               nrow=prms$P)
        ## add lines per patch
        if(size=='LITTLE') {
          for(ii in 1:prms$P)
            lines(x=x.vals,
                  y=num.by.patch[ii,],
                  col=makeTransparent(cc, alpha=0.1),
                  lwd=0.2)
        }
        ## add mean lines across patches
        lines(x=x.vals,
              y=colMeans(num.by.patch),
              col=cc,
              lwd=lwd)
      }
      add.lines(case='R')
      add.lines(case='C')

      if(size=='BIG') {
        abline(h=prms$K, lty=2, col='gray')
        par(new=TRUE)
        l1.vals <- sapply(out, calc.mean.trait, locus='l1', case='C')
        plot(x=x.vals,
             y=l1.vals,
             lwd=0.5,
             col=cols['x'],
             type='l',
             xaxt='n',
             yaxt='n',
             xlab='',
             ylab='',
             ylim=c(0.01,0.25),
             xlim=c(1,max(x.vals)))
        axis(4, las=1)
        text(expression('Trait value,'~italic(x[j])),
             x=prms$n.gens+2e3, y=0.125, xpd=NA, srt=270)
        arrows(x0=1,      y0=0.26, x1=-1988,    y1=0.305, xpd=NA, code=0)
        arrows(x0=100,    y0=0.26, x1=2320,     y1=0.305, xpd=NA, code=0)
        arrows(x0=1e4-99, y0=0.26, x1=1e4-1968-300, y1=0.305, xpd=NA, code=0)
        arrows(x0=1e4,    y0=0.26, x1=1e4+2300-300, y1=0.305, xpd=NA, code=0)

        ## add panel labels
        if(lab!='') {
          points(x=0.1*1e3, y=par('usr')[4]*0.95, pch=15,
                 col=makeTransparent('white', alpha=1), cex=2.5)
          text(x=-0.5*1e3, y=par('usr')[4]*0.95, lab, cex=1, pos=4, col='black')
        }
      }
    }

    ## big guys
    add.panel(prms=prms.1,
             out=out.1$pop.list[round(seq(from=1,
                                          to=prms.1$n.gens,
                                          length=1e3))],
             'BIG', lab='a')
    
    ## cols <- rep('white', 3)
    add.panel(prms=prms.200,
             out=out.200$pop.list[round(seq(from=1,
                                            to=prms.200$n.gens,
                                            length=1e3))],
             'BIG', lab='b')

    legend(2500, 0.39,
           legend=c('Predator',
                    'Prey',
                    expression('Trait value,'~italic(x[j]))),
           lty=c(1.5,1.5,1.5),
           col=c('orange', 'green4', 'black'),
           ## col=cols[c(2,3,1)],
           bty='n',
           bg = 'white',
           cex=0.7,
           xpd=NA)

    ## cols <- c(x='black',
    ##           C='orange',
    ##           R='green4')
    
    ## little guys
    add.panel(prms=prms.1, out.1$pop.list[1:1e2],
              'LITTLE', lab='')
    add.panel(prms=prms.1, out.1$pop.list[(prms.1$n.gens-1e2+1):prms.1$n.gens],
              'LITTLE', lab='')
    ## cols <- rep('white', 3)
    add.panel(prms=prms.200,
              out.200$pop.list[1:1e2],
              'LITTLE', lab='')
    add.panel(prms=prms.200,
              out.200$pop.list[(prms.200$n.gens-1e2+1):prms.200$n.gens],
              'LITTLE', lab='')
    
    ## main panels
    mtext(expression(paste("Generation ( x 10"^"3"," )",sep="")),
          side=1, line=0.3, at=0.3, cex=0.7, adj=0, outer=TRUE)
    mtext(c('Mean population size', 'Population size'),
          side=2, line=-0.25, at=c(0.075,0.62), cex=0.7, adj=0, outer=TRUE)
    
  }
  
  pdf.f(g, file.name, height=5, width=2.75)
}

make.fig('run_dynamics.pdf')
