## *************** nice little pdf function ****************
pdf.f <- function(f, file, ...) {
  cat(sprintf("Writing %s\n", file))
  pdf(file, ...)
  on.exit(dev.off())
  f()
}

## *************** make a colour transparent ***************
makeTransparent <- function(..., alpha=0.5) {
  if(alpha<0 | alpha>1) stop("alpha must be between 0 and 1")
  alpha = floor(255*alpha)  
  newColor = col2rgb(col=unlist(list(...)), alpha=FALSE)
  .makeTransparent = function(col, alpha) {
    rgb(red=col[1], green=col[2], blue=col[3], alpha=alpha, maxColorValue=255)
  }
  apply(newColor, 2, .makeTransparent, alpha=alpha)
}

## ************* plot output from a single run *************
plot.single.run <- function(fn, out) {
  make.fig <- function() {

    layout(matrix(1, ncol=1))
    par(oma=c(2.1,2,0.2,2), mar=c(0.2, 0.4, 0.2, 0.4),
        mgp=c(2,0.2,0), tcl=0, cex.axis=1, cex.main=1, pty='s')

    ## make an empty plot
    out <- out[!sapply(out, is.null)]
    max.num <- max(sapply(out, function(x)
      max(c(x[['C']]$counts, x[['R']]$counts))))
    x.vals <- prms$save.gens[1:length(out)]
    plot(NA,
         ## xlim=c(1,prms$n.gens),
         xlim=c(1,max(x.vals)),
         ylim=c(0,max.num),
         xlab='',
         ylab='',
         las=1)

    options(scipen=1e5)
    add.lines <- function(case) {
      cc <- ifelse(case=='C', 'orange', 'green4')
      ##tried to change the colours and failed, may come back to this
      ## cc <- turbo(3)
      ## names(cc) <- c('C', 'orange', 'green4')
      ## extract counts
      num <- lapply(out, function(x) x[[case]]$counts)
      ## sum totals across types within patches
      num.by.patch <- matrix(sapply(num, colSums),
                             nrow=prms$P)
      ## add lines per patch
      for(ii in 1:prms$P)
        lines(x=x.vals,
              y=num.by.patch[ii,],
              col=makeTransparent(cc, alpha=0.1),
              lwd=0.2)
      ## add mean lines across patches
      lines(x=x.vals,
            y=colMeans(num.by.patch),
            col=cc,
            lwd=2)
      cat(sprintf('Total pop size (%s) = %d\n',
                  case,
                  round(mean(colSums(num.by.patch)))))
    }
    add.lines(case='C')
    add.lines(case='R')
    abline(h=prms$K, lty=2, col='gray')

    par(new=TRUE)
    l1.vals <- sapply(out, calc.mean.trait, locus='l1', case='C')
    plot(x=x.vals,
         y=l1.vals,
         lwd=1,
         col='black',
         type='l',
         xaxt='n',
         yaxt='n',
         xlab='',
         ylab='',
         ylim=c(0,0.3),
         ## xlim=c(1,prms$n.gens),
         xlim=c(1,max(x.vals)))
    axis(4, las=1)
    
    legend('bottomright',
           legend=c('Predator', 'Prey', 'Trait value (x)'),
           lty=c(1.5,1.5,1.5),
           col=c('orange', 'green4', 'black'),
           ##col=turbo(3),
           bty='n')

    mtext('Generation', side=1, line=1, at=0.55, outer=TRUE)
    mtext('Population size', side=2, line=0.6, at=0.5, outer=TRUE)
    mtext('Trait value', side=4, line=0.6, at=0.5, outer=TRUE)
    
  }
  pdf.f(make.fig,
        fn,
        height=6,
        width=7)
}
