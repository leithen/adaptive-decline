## add dimension names to a population
add.dim.names <- function(pop) {
  dimnames(pop$traits) <-
    list(type=paste('t', 1:nrow(pop$traits), sep=''),
         locus=paste('l', 1:ncol(pop$traits), sep=''))
  ind <- names(pop) %in% c('counts',
                           'counts.move',
                           'counts.born')
  pop[ind] <- lapply(pop[ind], function(x) {
    dimnames(x) <-
      list(type=paste('t', 1:nrow(pop$counts), sep=''),
           patch=paste('p', 1:ncol(pop$counts), sep=''))
    x
  })
  pop
}

## initialize a population (con=TRUE for consumers, con=FALSE for resources)
initialize.pop <- function(prms, con=TRUE) {
  if(con) {
    init.pop <- prms$init.pop.size['C']
    traits <- matrix(prms$init.traits$C, nrow=1)
  }
  if(!con) {
    init.pop <- prms$init.pop.size['R']
    traits <- matrix(prms$init.traits$R, nrow=1)
  }

  counts <- matrix(0, nrow=1, ncol=prms$P)
  counts[1,] <- round(runif(prms$P)*init.pop)
  add.dim.names(list(counts=counts, traits=traits))
}

## drop trait types that are extinct
drop.missing.types <- function(pop) {
  if(is.null(pop)) return(pop)
  ## check whether any types are extinct
  extinct <- which(rowSums(pop$counts)<1e-5)
  ## if not, return the population
  if(length(extinct)==0) return(pop)

  ## if one or more types are extinct, remove them
  pop$counts <- pop$counts[-extinct,,drop=FALSE]
  pop$traits <- pop$traits[-extinct,,drop=FALSE]
  pop$counts.move <- pop$counts.move[-extinct,,drop=FALSE]
  pop$counts.born <- pop$counts.born[-extinct,,drop=FALSE]

  if(nrow(pop$counts)==0) return(NULL)
  ## reset dimnames
  add.dim.names(pop)
}

## *** mutation ***
mutate <- function(prms, pop, case, gen) {

  ## figure out which traits are subject to mutation
  if(case=='C') pp <- prms$mut.weights$C
  if(case=='R') pp <- prms$mut.weights$R
  ## if none, break out
  if(sum(pp)==0) return(pop)

  num.types <- rowSums(pop$counts)

  ## draw number of mutants (this quantity is constrained so that we
  ## never have more mutants than allowed types, prms$n.types.max)
  num.mutants <- prms$n.types.max - length(num.types)
  
  ## break out if no mutants (dont need to execute the rest)
  if(num.mutants==0) return(pop)

  ## figure out where mutants are
  mut.prob <- pop$counts
  if(sum(mut.prob)==0) return(pop)
  
  tentative.mutants <- matrix(rmultinom(n=1,
                                        size=num.mutants,
                                        prob=mut.prob),
                              ncol=ncol(pop$counts))
  ## the above allows there to be more mutants than individuals in a
  ## given class (a very rare outcome). If this happens, just reduce
  ## the number of mutants.
  mutants <- tentative.mutants
  too.many <- tentative.mutants>pop$counts
  if(any(too.many)) {
    mutants[too.many] <- pmin(mutants[too.many], pop$counts[too.many])
    mutants <- floor(mutants)
  }

  ind.from <- which(mutants>0, arr.ind=TRUE)
  patch <- rep(ind.from[,2], mutants[ind.from])
  trait.row.orig <- rep(ind.from[,1], mutants[ind.from])
  trait.row.dest <- 1:sum(mutants) + nrow(pop$traits)

  ind.to <- cbind(trait.row.dest, patch)

  ## augment counts and traits matrices to create new empty rows
  ##
  ## counts
  new.mat <- matrix(0, ncol=ncol(pop$counts), nrow=sum(mutants))
  pop$counts <- rbind(pop$counts, new.mat)
  ## traits
  new.mat <- matrix(0, ncol=ncol(pop$traits), nrow=sum(mutants))
  pop$traits <- rbind(pop$traits, new.mat)

  ## fill in counts matrix
  ##
  ## remove 1 individual
  pop$counts[ind.from] <- pop$counts[ind.from]-mutants[ind.from]
  ## add 1 individual to the new mutated type
  pop$counts[ind.to] <- 1

  ## fill in mutant traits with parental values
  pop$traits[trait.row.dest,] <- pop$traits[trait.row.orig,]

  ## for each mutant, figure out which locus mutates
  mut.loc <- sample.int(n=ncol(pop$traits),
                        size=length(trait.row.dest),
                        replace=TRUE,
                        prob=pp)

  ## calculate mutational effect sizes
  mut.effects <- rnorm(sum(mutants), 0, prms$sigma.mu) # Does as many
                                        # draws as you have mutants,
                                        # and the sd is the mutation size
  ## add mutational effects
  ind <- cbind(trait.row.dest, mut.loc) # gives us the index in
                                        # pop$traits (type and locus)
                                        # that we are going to change
  pop$traits[ind] <- pop$traits[ind] + mut.effects # we change it to
                                        # itself plus the mutation
                                        # effect calculated earlier
  
  ## ensure that mutated traits are all valid values
  if(case=='C') {
    ## constrain all traits to be greater than 0
    pop$traits[] <- pmax(0,pop$traits)
  }

  ## round traits to specified precision (this helps collapse traits
  ## that are effectively the same into a single category (this
  ## happens next).
  pop$traits <- round(pop$traits, digits=prms$trait.precision)

  ## find and combine duplicate phenotypes
  key <- apply(pop$traits, 1, paste, collapse='_')

  ## figure out duplicated rows
  key.split <- split(1:nrow(pop$traits), f=key)
  num.types <- length(key.split)
  ## create new counts and traits for collapsed categories
  new.counts <- matrix(0,
                       nrow=num.types,
                       ncol=prms$P)
  new.traits <- matrix(0,
                       nrow=num.types,
                       ncol=ncol(pop$traits))
  ## and collapse into smaller counts/traits matrices
  for(ii in seq_along(key.split)) {
    ## sum of the rows that are duplicate types
    new.counts[ii,] <- colSums(pop$counts[key.split[[ii]],,drop=FALSE])
    ## take the trait values of one of the duplicates
    new.traits[ii,] <- pop$traits[key.split[[ii]],,drop=FALSE][1,] 
  }
  
  ## return mutated popuation
  add.dim.names(list(counts=new.counts, traits=new.traits))
}

## *** movement between patches ***
move <- function(prms, pop, gen, move) {

  ## figure out how many individuals move
  num.move <- rbinom(n=length(pop$counts), size=pop$counts, prob=move)
  ## if no movers
  if(sum(num.move)==0) {
    pop$counts.move <- pop$counts*0
    return(pop)
  }
  
  ## create structures to store movers and their destinations
  destination <- origin <- pop$counts*0
  origin[] <- num.move

  ## go through and move each set of movers (individuals of same trait
  ## type within same patch)
  origin.ind <- which(origin>0, arr.ind=TRUE)
  for(ii in 1:nrow(origin.ind)) {
    tt <- origin.ind[ii,'type']
    pp <- origin.ind[ii,'patch']
    dest <- rmultinom(n=1, size=origin[tt,pp], prob=prms$move.mat[,pp])
    destination[tt,] <- destination[tt,] + dest
  }

  ## update counts (do the actual movement) and then return pop
  pop$counts <- pop$counts-origin+destination
  pop$counts.move <- origin
  pop
}

## *** feed and breed ***
feed.and.breed <- function(prms, C, R, gen) {

  ## calculate trait-dependent consumer rates
  attack.rate <- prms$a.0 * C$traits[,'l1'] / (1 + prms$a.1*C$traits[,'l1'])
  death.rate <- prms$d.0 + prms$d.1 * C$traits[,'l1']
  conversion.rate <- prms$b * C$traits[,'l2'] / (1 + prms$gamma*C$traits[,'l2'])
  
  R.prime <- R
  C.prime <- C

  ## accounting for times when either predator or prey go extinct
  if(is.null(C)) return(list(C=C, R=R.prime))
  if(is.null(R)){
    C.died <- rbinom(n=length(C.prime$counts),
                     size=C.prime$counts,
                     prob=death.rate)
    C.died <- matrix(C.died, ncol=prms$P)
    C.prime.prime <- C.prime
    C.prime.prime$counts[] <- pmax(0, C.prime$counts - C.died)
    return(list(C=C.prime.prime, R=R))
  }
  
  R.site.total <- colSums(R$counts)
  C.site.total <- colSums(C$counts)

  ## ------------------------------
  ## calculate R in next time step
  R.born  <- pmax(0, prms$r * (1-R$counts / prms$K) * R$counts)
  R.born  <- rpois(n=length(R.born), lambda=R.born)
  R.born  <- matrix(R.born, ncol=prms$P)

  R.die.natural <- rbinom(n=length(R$counts),
                          size=R$counts,
                          prob=prms$d.R)
  
  R.prime$counts[] <- pmax(0, R$counts + R.born - R.die.natural)
  R.prime.site.total <- colSums(R.prime$counts)

  ## handling time
  R.attacked <- t(R.prime.site.total %*% t(attack.rate))
  R.handled <- R.attacked / (1 + prms$h*R.attacked)
  R.eaten.by.C <- R.handled * C$counts
 
  R.eaten.by.C <- rpois(n=length(R.eaten.by.C), lambda=R.eaten.by.C)
  R.eaten.by.C <- matrix(R.eaten.by.C, ncol=prms$P)
  R.eaten <- colSums(R.eaten.by.C)

  R.prime.prime <- R.prime
  R.prime.prime$counts[] <- pmax(0, R.prime$counts - R.eaten)

  ## ------------------------------
  ## calculate C in next time step
  C.born <- pmax(0, conversion.rate * R.eaten.by.C)
  C.born <- rpois(n=length(C.born), lambda=C.born)
  C.born <- matrix(C.born, ncol=prms$P)

  C.prime$counts[] <- pmax(0, C$counts + C.born)
  ## track the number born per type
  C.prime$counts.born <- C.prime$counts*0
  C.prime$counts.born[] <- pmax(0, C.born)

  C.died <- rbinom(n=length(C.prime$counts),
                   size=C.prime$counts,
                   prob=death.rate)
  C.died <- matrix(C.died, ncol=prms$P)
  
  C.prime.prime <- C.prime
  C.prime.prime$counts[] <- pmax(0, C.prime$counts - C.died)
  
  list(C=C.prime.prime, R=R.prime.prime)
}

## iterate a single generation
next.gen <- function(prms, C, R, debug=FALSE, gen) {

  ## mutation
  if(debug) cat('mutation\n')
  if(gen>0) {
    C <- mutate(prms, pop=C, case='C', gen=gen)
    R <- mutate(prms, pop=R, case='R', gen=gen)
    C <- drop.missing.types(C)
    R <- drop.missing.types(R)
  }
  
  ## migration
  if(debug) cat('movement\n')
  if(prms$P>1) {
    C <- move(prms=prms, pop=C, gen=gen, move=prms$m.C)
    R <- move(prms=prms, pop=R, gen=gen, move=prms$m.R)
    C <- drop.missing.types(C)
    R <- drop.missing.types(R)
  }

  ## population growth and predation
  if(debug) cat('feed and bread\n')
  out <- feed.and.breed(prms=prms, C=C, R=R, gen=gen)
  C <- drop.missing.types(out$C)
  R <- drop.missing.types(out$R)

  list(C=C, R=R)  
}
