## basic parameter set
base.prms <- function(## initial conditions
                      init.pop.size=c(C=1e2,R=1e3),
                      init.traits=list(C=c(0.1,1,1),
                                       R=c(1,1,1)),
                      ## mutation rate and constraints
                      mut.weights=list(C=c(0,0,0),
                                       R=c(0,0,0)), # no traits mutate
                      sigma.mu=0.01,
                      ## lotka-volterra params
                     
                      r=0.5, # prey growth rate
                      K=1e5, # prey carrying capacity
                      d.R=0, # prey intrinsic death rate
                      
                      b=0.1, # conversion efficiency
                      h=0.1, # handling time saturation rate

                      ## attack rate parameters
                      a.0=0.0005,
                      a.1=1,

                      ## death rate parameters
                      d.0=0.1, # intercept for death rate mod
                      d.1=0.5, # slope effect for death rate mod
                      
                      gamma=0, # conversion rate saturation rate

                      ## dispersal
                      m.C=1e-4,
                      m.R=1e-4,
                      
                      P=1,
                      move.mode='queen', # options are queen, rook, pawn

                      ## simulation parameters
                      n.types.max=10, ## max number of types allowed
                                      ## in the population at any
                                      ## given time
                      trait.precision=2, ## how many digits precision
                                         ## to track for traits
                                         ## (larger=fewer effectively
                                         ## different segregating
                                         ## types at once)
                      n.gens=100,
                      burnin=0,
                      max.burnin.tries=100,
                      print.every=1,
                      n.saves=1e3,
                      save.type='entire',
                      file.name='saved/res.RData'
                      ) {

  inputs <- lapply(as.list(match.call())[-1], eval.parent)
  inputs.f <- lapply(formals(), eval)

  for(v in names(inputs.f))
    if(!(v %in% names(inputs)))
      inputs <- append(inputs, inputs.f[v]) ## add formal args
  inputs <- inputs[order(names(inputs))] ## order for consistency
  
  update.prms(inputs)
}

## function to create dependent parameters/structures
update.prms <- function(inputs) {

  inputs$n.saves <- min(inputs$n.saves, inputs$n.gens)
  if(inputs$save.type=='entire')
    inputs$save.gens <- round(seq(from=1,
                                  to=inputs$n.gens,
                                  length=inputs$n.saves))
  if(inputs$save.type=='final')
    inputs$save.gens <- (inputs$n.gens-inputs$n.saves+1):inputs$n.gens
  
  if(inputs$P==1) {
    inputs$move.mat <- 1
  } else {

    ## can move to any other patch
    if(inputs$move.mode=='queen') {
      dm <- matrix(1,
                   nrow=inputs$P,
                   ncol=inputs$P)
      diag(dm) <- 0
    }

    ## linear arrangement of patches, can only move forwards
    ## wraparound from last patch into first
    if(inputs$move.mode=='pawn') {
      ## make empty matrix of correct size
      dm <- matrix(0 ,
                   nrow=inputs$P,
                   ncol=inputs$P)
      
      ## add the probability of moving to the next patch
      ## wraparound last patch to first patch 
      for (i in 1:inputs$P){
        ##cat(sprintf("iteration %d \n" ,i))
        dm[i,i%%inputs$P+1] <- 1
      }
    
    }
    

    ## linear arrangement of patches can move forwards or back
    ## wraparound from last patch into first
    if(inputs$move.mode=='rook') {
      ## empty matrix of correct size
      dm <- matrix(0 ,
                   nrow=inputs$P,
                   ncol=inputs$P)
      
      ## add the probability of moving to the next patch and previous
      ## patch wraparound last patch to first patch not sure the most
      ## elegant way to deal with the wraparound for moving to the
      ## previous patch
      for(i in 1:inputs$P) {
        dm[i,i%%inputs$P+1] <- 1
        
        if(i == 1) {
          dm[i,inputs$P] <- 1
        }
        else {
          dm[i,i-1] <- 1
        }
      }
    }

    ## divide columns by total so that total dispersal probability is
    ## independent of the number of patches
    inputs$move.mat <- dm/colSums(dm)
  }

  return(prms=inputs)
}
