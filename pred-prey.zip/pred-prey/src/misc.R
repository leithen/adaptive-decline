## Useful functions

calc.pop.size <- function(pp, case) {
  sum(pp[[case]]$counts)
}

calc.mean.trait <- function(pp, locus, case) {
  if(is.null(pp[[case]])) return(NA)
  sum(rowSums(pp[[case]]$counts * pp[[case]]$traits[,locus])) /
    sum(pp[[case]]$counts)
}

## number of patches with nonzero counts
num.extant <- function(pp, case) 
  sum(pp[[case]][['counts']]!=0)
