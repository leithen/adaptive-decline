## check for extinction of either species
extinct <- function(pop) {
  if(is.null(pop$C) | is.null(pop$R)) {
    return(TRUE)
  }
  FALSE
}

## identify which species is extinct
which.extinct <- function(pop) {
  if(is.null(pop$C)) return('C')
  if(is.null(pop$R)) return('R')
}

## run the model and save populations
run.sim <- function(prms, print=T, plot=F) {

  C <- initialize.pop(prms, con=TRUE)
  R <- initialize.pop(prms, con=FALSE)
  extinct.species <- NULL
  
  if(prms$burnin>0) {
    ii <- 1
    num.tries <- 1
    while(ii <= prms$burnin & num.tries<=prms$max.burnin.tries) {
      out.next <- next.gen(prms,
                           C=C,
                           R=R,
                           debug=FALSE,
                           gen=0)
      if(extinct(out.next)) {
        if(print)
          cat(sprintf('Extinction of %s during burn-in (gen %d)\n',
                      which.extinct(out.next),
                      ii))
        C <- initialize.pop(prms, con=TRUE)
        R <- initialize.pop(prms, con=FALSE)
        ii <- 0
        num.tries <- num.tries+1
        if(num.tries>prms$max.burnin.tries)
          return(list(pop.list=NULL,
                      num.gens=0,
                      extinct.species=NULL))
      } else {
        C <- out.next$C
        R <- out.next$R
      }
      ii <- ii+1
    }
  }
  
  pop.list <- vector('list', prms$n.saves) ## Create pop list of iterations
  names(pop.list) <- prms$save.gens

  ii.save <- 1
  for(ii in 1:prms$n.gens) {
    ## iterate a single generation 
    out.next <- next.gen(prms,
                         C=C,
                         R=R,
                         debug=FALSE,
                         gen=ii)
    
    if(extinct(out.next)) {
      if(print)
        cat(sprintf('Extinction of %s (gen %d)\n',
                    which.extinct(out.next),
                    ii))
      extinct.species <- which.extinct(out.next)
      if(ii.save>1) {
        pop.list <- pop.list[1:(ii.save-1)]
      } else {
        pop.list <- NULL
      }
      break
    }
    
    C <- out.next$C
    R <- out.next$R

    num.c <- mean(colSums(C$counts))
    num.r <- mean(colSums(R$counts))
    if(print) {
      if(ii%%prms$print.every==0) {
        cat(sprintf('Generation %d\n', ii))
        cat(sprintf('Consumer population size (per patch): %3.0f\n', num.c))
        cat(sprintf('Resource population size (per patch): %3.0f\n', num.r))
        cat(sprintf('Mean consumer l1 trait value: %2.4f\n',
                    calc.mean.trait(out.next, locus='l1', case='C')))
        cat(sprintf('Mean consumer l2 trait value: %2.4f\n',
                    calc.mean.trait(out.next, locus='l2', case='C')))
        cat(sprintf('%d/%d predator free patches\n',
                    sum(colSums(C$counts)==0), prms$P))
      }
    }
    if(ii %in% prms$save.gens) {
      pop.list[[ii.save]] <- list(C=C, R=R)
      ii.save <- ii.save+1
    }
  }

  mean.l1.C <- calc.mean.trait(out.next, locus='l1', case='C')
  if(print)  cat(sprintf('Persisted for %d gens, final l1=%2.5f.\n',
                        ii, mean.l1.C))
  
  ## return saved populations
  return(list(pop.list=pop.list,
              num.gens=ii,
              extinct.species=extinct.species))
}
